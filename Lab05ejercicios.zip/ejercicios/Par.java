package ejercicios;

public class Par<K, V> {
    private K primero;
    private V segundo;

    public Par(K primero, V segundo) {
        this.primero = primero;
        this.segundo = segundo;
    }

    public K getPrimero() {
        return primero;
    }

    public void setPrimero(K primero) {
        this.primero = primero;
    }

    public V getSegundo() {
        return segundo;
    }

    public void setSegundo(V segundo) {
        this.segundo = segundo;
    }

    public String toString() {
        return "(" + primero + ", " + segundo + ")";
    }

    public boolean esIgual(Par<K, V> otro) {
        if (otro == null) return false;
        return this.primero.equals(otro.getPrimero()) && this.segundo.equals(otro.getSegundo());
    }

    public static <K, V> void imprimirPar(Par<K, V> par) {
        System.out.println(par);
    }
}
