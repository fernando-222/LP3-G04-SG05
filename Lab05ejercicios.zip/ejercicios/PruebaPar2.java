package ejercicios;

public class PruebaPar2 {
    public static void main(String[] args) {
        Par<String, Integer> par1 = new Par<>("Edad", 20);
        Par<String, Integer> par2 = new Par<>("Edad", 20);
        Par<String, Integer> par3 = new Par<>("Altura", 180);

        System.out.println(par1.esIgual(par2));
        System.out.println(par1.esIgual(par3));
    }
}
