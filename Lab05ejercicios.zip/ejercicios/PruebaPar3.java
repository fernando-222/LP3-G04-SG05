package ejercicios;

public class PruebaPar3 {
    public static void main(String[] args) {
        Par<String, String> par1 = new Par<>("Nombre", "Ana");
        Par<Double, Boolean> par2 = new Par<>(5.5, true);

        Par.imprimirPar(par1);
        Par.imprimirPar(par2);
    }
}
