package ejercicios;

public class PruebaContenedor {
    public static void main(String[] args) {
        Contenedor<String, Integer> contenedor = new Contenedor<>();

        contenedor.agregar(new Par<>("Edad", 25));
        contenedor.agregar(new Par<>("Altura", 180));
        contenedor.agregar(new Par<>("Peso", 70));

        contenedor.mostrar();

        System.out.println("Primer par: " + contenedor.obtener(0));
        System.out.println("Todos los pares: " + contenedor.obtenerTodos());
    }
}
