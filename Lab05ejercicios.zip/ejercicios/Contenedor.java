package ejercicios;

import java.util.ArrayList;
import java.util.List;

public class Contenedor<K, V> {
    private List<Par<K, V>> lista;

    public Contenedor() {
        lista = new ArrayList<>();
    }

    public void agregar(Par<K, V> par) {
        lista.add(par);
    }

    public Par<K, V> obtener(int indice) {
        if (indice < 0 || indice >= lista.size()) {
            throw new IndexOutOfBoundsException("Índice fuera de rango");
        }
        return lista.get(indice);
    }

    public List<Par<K, V>> obtenerTodos() {
        return lista;
    }

    public void mostrar() {
        for (Par<K, V> par : lista) {
            System.out.println(par);
        }
    }
}
